// Grupo: José Miguel Prieto Páez y Daniel Rodríguez Sánchez

package org.mps.deque;

public class DoubleLinkedQueueException extends RuntimeException {
    public DoubleLinkedQueueException(String message) {
        super(message);
    }
}
